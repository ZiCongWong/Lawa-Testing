create definer = lawa@`%` event hourly_table_creation on schedule
    every '1' HOUR
        starts '2025-08-23 20:56:22'
    enable
    do
    BEGIN
        CALL auto_create_monthly_tables();
    END;

