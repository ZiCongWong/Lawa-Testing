create
    definer = lawa@`%` procedure auto_create_monthly_tables()
BEGIN
    DECLARE current_db VARCHAR(64);
    DECLARE current_table VARCHAR(64);
    DECLARE table_count INT;
    DECLARE i INT DEFAULT 0;

    -- 获取当前年月（格式：YYYYMM）
    SET @current_month = DATE_FORMAT(NOW(), '%Y%m');

    -- 创建临时表
    CREATE TEMPORARY TABLE IF NOT EXISTS monthly_tables_temp (
                                                                 id INT AUTO_INCREMENT PRIMARY KEY,
                                                                 db_name VARCHAR(64),
                                                                 table_name VARCHAR(64)
    );
    TRUNCATE TABLE monthly_tables_temp;

    -- 只查找当前月份的表
    INSERT INTO monthly_tables_temp (db_name, table_name)
    SELECT t.table_schema, t.table_name
    FROM information_schema.tables t
    WHERE t.table_schema NOT IN ('mysql', 'information_schema', 'performance_schema', 'sys')
      AND t.table_name REGEXP CONCAT('^[a-z_]+_', @current_month, '$');

    SET table_count = (SELECT COUNT(*) FROM monthly_tables_temp);

    -- 处理每个表
    WHILE i < table_count DO
            SET i = i + 1;

            SELECT db_name, table_name INTO current_db, current_table
            FROM monthly_tables_temp WHERE id = i;

            BEGIN
                DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
                    BEGIN
                        SELECT CONCAT('❌ 处理失败: ', current_db, '.', current_table) AS error;
                    END;

                -- 计算下个月（确保格式为YYYYMM）
                SET @year = CAST(SUBSTRING(@current_month, 1, 4) AS UNSIGNED);
                SET @month = CAST(SUBSTRING(@current_month, 5, 2) AS UNSIGNED);

                IF @month = 12 THEN
                    SET @next_year = @year + 1;
                    SET @next_month = '01';
                ELSE
                    SET @next_year = @year;
                    SET @next_month = LPAD(@month + 1, 2, '0');
                END IF;

                SET @next_month_str = CONCAT(@next_year, @next_month);
                SET @table_prefix = SUBSTRING(current_table, 1, LENGTH(current_table) - 7);
                SET @new_table_name = CONCAT(@table_prefix, '_', @next_month_str);

                -- 检查表是否存在
                SET @check_sql = CONCAT(
                        'SELECT COUNT(*) INTO @table_exists ',
                        'FROM information_schema.tables ',
                        'WHERE table_schema = ''', current_db, ''' ',
                        'AND table_name = ''', @new_table_name, ''''
                                 );
                PREPARE stmt_check FROM @check_sql;
                EXECUTE stmt_check;
                DEALLOCATE PREPARE stmt_check;

                IF @table_exists = 0 THEN
                    -- 创建新表
                    SET @create_sql = CONCAT(
                            'CREATE TABLE ', current_db, '.', @new_table_name,
                            ' LIKE ', current_db, '.', current_table
                                      );
                    PREPARE stmt_create FROM @create_sql;
                    EXECUTE stmt_create;
                    DEALLOCATE PREPARE stmt_create;

                    SELECT CONCAT('✅ 创建: ', current_db, '.', @new_table_name) AS result;
                ELSE
                    SELECT CONCAT('⏩ 已存在: ', current_db, '.', @new_table_name) AS log;
                END IF;
            END;
        END WHILE;

    DROP TEMPORARY TABLE monthly_tables_temp;
END;

